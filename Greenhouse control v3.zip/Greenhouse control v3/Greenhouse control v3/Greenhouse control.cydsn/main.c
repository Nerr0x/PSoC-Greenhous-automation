/* ========================================
 *
 * Copyright Peer Kröll, 04.05.2023
 * 
 * PSOC Project Greenhouse v1
 *
 * ========================================*/
#include <project.h>
#include "stdio.h"
#include "stdlib.h"
#include "string.h"

/* Project Defines */
#define FALSE  0
#define TRUE   1
#define TRANSMIT_BUFFER_SIZE  16
#define tickDelay(tick) CyDelayUs(tick)

// Defined Variables
#define A  6
#define B 64
#define C 60
#define D 10
#define E  9
#define F 55
#define G  0
#define H 480
#define I 70
#define J 410

// Functions and Interrupt Prototypes
void SetUpStart(void);
void OWWriteBit(int bit);
int OWReadBit(void);
int OWTouchReset(void);
int OWReadByte(void);
void OWWriteByte(int data);
int DHTread(void);
void PWMPosition(int increment);   
void WriteEEPROM();
void OneWireTemp(void);
void UserInput(void);
void ControlUnit(void);
void UserWriteDate(void);
void UserWriteTime(void);
void UserWriteDateTimeOut(void);
int UserWriteDateTimeProve(int DateOrTime);
void WriteDateTimeEEPROM(int DateOrTime);
void ReadDateTime(int DateOrTime);
void TimeControl(void);
void EEPROMPrintJSON(void);
void ClearEEPROM(void);
void PrintTerminal(void);
void LiveData(void);
void OneWireAddress(int address);

// Interrupt Prototypes 
CY_ISR_PROTO(isr_TimerData);    // Safe Data every 15 minutes 
CY_ISR_PROTO(UART_ISR);         // Userinputs
CY_ISR_PROTO(isr_TimeUpdate);         // Change Time every minute
CY_ISR_PROTO(isr_LiveData);

// Variables
char key = 0;                   // Userinput (UART)
char keySafe[12];               // Safe multiple userinputs
uint8 keyCounter = 0;           // Count multiple userinputs and gives information about he position
uint8 flagTimerData = 0;        // Flag for the TimerData
uint8 flagTime = 0;             // Flag for the Time
uint8 flagLiveData = 0;         // Flag for printing out the live data
uint8 extraHeating = 0;         // Turn on/off the heater
uint8 waterSprayer = 0;         // Turn on/off the watersprayer
static int temperature = 99;    // Temperature of the DHT11
static int humidity = 99;       // Humidity of the DHT11
uint16 posEEPROM;               // Position of the last safed data 
uint16 soilTemp_1;              // Temperature of the first Dallas Sensor
uint16 soilTemp_2;              // Temperature of the second Dallas Sensor
uint16 mois;                    // Soil Moisture  
uint8 OneWireAddressValues[16]; // Save the addresses of the Soil temperature sensors
uint8 actualPWMPos;

/* MAIN */
int main()
{
    // Activate Interrupts
    CyGlobalIntEnable;
    
    // Setup all interrupts, UART, Timer, EEPROM, ADC and PWM (Topdesign)
    SetUpStart();
    
    for(;;)
    {   
        if(flagTime == TRUE)
        {  
                TimeControl();              // The created clock gets updated every minute
                flagTime = FALSE;           // Reset the flag
               
        }
        if(flagTimerData == TRUE){
                OneWireTemp();
                mois = ADC_DelSig_1_Read8(); // Get the measurement and AD-Convertion of the soil moisture
                WriteEEPROM();               // After every 15min cycle -> Write the measured data to the EEPROM

                flagTimerData = FALSE;       // Reset the outputflag
        }
        if(flagLiveData == TRUE){
                if(keySafe[0] == 'W'){  // Print out live data               
                        LiveData();     // Print out live data
                }
                DHTread();              // Measure Temperature and Humidity
                ControlUnit();          // This function turns on/off the heating and watersprayer  
                if(temperature >= 20 && temperature <= 25){     // Execute when a Temperatur between 20 and 25 got recognized    
                        PWMPosition(temperature);               // Function to change the PWM position
                } 
                flagLiveData = FALSE;   // Reset the 1 minute timer flag
        }
 
        if(key != '0')
                UserInput();            // Userinterface by pressing a button  
    }
}

/* FUNCTIONS */
void SetUpStart(void){
/*=====================================================================================
Start and setup all interrupts, UART, Timer, EEPROM, ADC and PWM (Topdesign).
Get the one wire addresses for later and setup the PWM position
=========================================================================================*/
    // UART + UART Interrupt
    UART_1_Start();                             
    UART_1_PutString("COM Port Open\n\n\r");    // Verify COM port is connected properly    
    isr_UART_StartEx(UART_ISR);                 // Start and enable der ISR for the UART
    isr_UART_Enable();    
    
    // Timer Interrupt + Timer
    isr_TimerData_Enable();
    isr_TimerData_StartEx(isr_TimerData);   // Start and enable der ISR for the Timer
    Timer_1_Start();                        // Start the timer1
    
    isr_TimeUpdate_Enable();
    isr_TimeUpdate_StartEx(isr_TimeUpdate); // Start and enable der ISR for the Timer
    Timer_2_Start();                        // Start the timer2
    
    isr_LiveData_Enable();
    isr_LiveData_StartEx(isr_LiveData);     // Start and enable der ISR for the Timer
    Timer_3_Start();                        // Start the timer3
    
    // EEPROM
    EEPROM_Start();
    EEPROM_Enable();
    
    // ADC
    ADC_DelSig_1_Start();
    ADC_DelSig_1_StartConvert();
    
    //PWM
    PWM_1_Start();
    Clock_PWM_Start();

    posEEPROM = EEPROM_ReadByte(0);         // Read the last data safe position to start writing (pos in the EEPROM)
    PrintTerminal();                        // Print out the Command Informations
    DHTread();                              // Measure the temperature, so that we can get a starting position
                                            // for the PWM for the case the temperatur is over 25 degree
    if(temperature > 25){
            PWM_1_WriteCompare(700);
            actualPWMPos = 5;
    }        
    else if(temperature < 20){
            PWM_1_WriteCompare(1500);
            actualPWMPos = 0;
    }
    else
            PWMPosition(temperature);
            
    for(int z = 0; z < 8; z++){     // Read the One Wire addresses from the EEPROM (Row 101 and 102 first 8 Bytes)
            OneWireAddressValues[z] = EEPROM_ReadByte(101*16 + z);
            OneWireAddressValues[z+8] = EEPROM_ReadByte(102*16 + z);
    }    
}
void OWWriteBit(int bit){
/*============================================================
Write/Send 8 Bit to the slave
=============================================================*/
        if (bit)
        {
                // Write '1' bit
                Pin_OneWire_Write(0x00); // Drives DQ low
                tickDelay(A);
                Pin_OneWire_Write(0x01); // Releases the bus
                tickDelay(B); // Complete the time slot and 10us recovery
        }
        else
        {
                // Write '0' bit
                Pin_OneWire_Write(0x00); // Drives DQ low
                tickDelay(C);
                Pin_OneWire_Write(0x01); // Releases the bus
                tickDelay(D);
        }
}
int OWReadBit(void){
/*============================================================
Read/Receive 8 Bit from the slave
=============================================================*/
        int result;

        Pin_OneWire_Write(0x00); // Drives DQ low
        tickDelay(A);
        Pin_OneWire_Write(0x01); // Releases the bus
        tickDelay(E);
        result =  Pin_OneWire_Read() & 0x01; // Sample the bit value from the slave
        tickDelay(F); // Complete the time slot and 10us recovery
        
        return result;
}
int OWTouchReset(void){
/*============================================================
Reset slave
=============================================================*/
        int result;
    
        tickDelay(G);
        Pin_OneWire_Write(0x00); //Drives DQ low
        tickDelay(H);
        Pin_OneWire_Write(0x01); // Releases the bus
        tickDelay(I);
        result = Pin_OneWire_Read() ^ 0x01;  // Sample for presence pulse from slave
        tickDelay(J);                        // Complete the reset sequence recovery
        return result;                       // Return sample presence pulse result
}
int OWReadByte(void){
/*============================================================
Call the function OWReadBit() 8 times to read/receive 1 Byte from the slave
=============================================================*/
        int loop, result = 0;

        for (loop = 0; loop < 8; loop++)
        {
                // shift the result to get it ready for the next bit
                result >>= 1;

                // if result is one, then set MS bit
                if (OWReadBit())
                        result |= 0x80;
        }
        return result;
}
void OWWriteByte(int data){
/*============================================================
Call the function OWWriteBit() 8 times to send/write 1 Byte to the slave
=============================================================*/
        int loop;

        // Loop to write each bit in the byte, LS-bit first
        for (loop = 0; loop < 8; loop++)
        {
                OWWriteBit(data & 0x01);

                // shift the data byte for the next bit
                data >>= 1;
        }
}
int DHTread(void) {     
/*============================================================
Measure the air temperature and air humidity
=============================================================*/
        uint8 IState;
        IState = CyEnterCriticalSection();  
        uint8 bits[5]; 
    	uint8 cnt = 7; 
        uint8 idx = 0; 

        int   calc = 0; 
        int   timeout = 0; 

        for(int i = 0; i < 5; i++)  
                bits[i] = 0; 
        DHT11_Write(0u); 
        CyDelay(19); 
        DHT11_Write(1u); 
        while(DHT11_Read() == 1) 
        { 
                timeout++; 
                if(timeout > 500) 
                        goto r99;  //DHT error function 
        } 
        while(DHT11_Read() == 0) 
        {         
                timeout++; 
                if(timeout > 500) 
                        goto r99; //DHT error function 
        } 
        calc = timeout; 
        timeout = 0; 
        while(DHT11_Read() == 1); 
        for(int i = 0; i < 40; i++) 
    	{ 
                timeout = 0; 
                while(DHT11_Read() == 0); 
                while(DHT11_Read() == 1) 
                        timeout++; 
                //Data acquiring point 
                if((timeout) > (calc/2)) 
                        bits[idx] |= (1 << cnt); 
                if(cnt == 0)   // next byte? 
       	        { 
       		            cnt = 7;    // restart at MSB 
       		            idx++;      // next byte! 
       	        } 
            	else cnt--; 
        } 
        humidity    = bits[0];  
        temperature = bits[2];  
        CyExitCriticalSection(IState); 
        CyDelay(1); 
        return 0; 
        r99:    //Goto label for error in DHT reading 
            
        humidity    = 99;  
        temperature = 99;  
        CyExitCriticalSection(IState); 
        
        return 99; 
}
void PWMPosition(int increment){
/*================================================================================
The function controls the position of the servo motor, which opens and closes the hatch depending on the measured
temperature. When the hatch is closed, the PWM is in his deafult Position which equals a value of 1500 in the
"PWM_1_WriteCompare(value);" command. Fully opened (90°) equals the value of 700.
----!The values can differ on different servo motors (you may have to change them)!----
Position 0    <=20°C or Reset(0%): 1500     (0°)    (default)
Position 1      21°C        (20%): 1340     (18°)
Position 2      22°C        (40%): 1180     (36°)
Position 3      23°C        (60%): 1020     (54°)
Position 4      24°C        (80%): 860      (72°)
Position 5    >=25°C       (100%): 700      (90°)
Now the hatch opens or closes a few steps. The change of the position gets calculated in the switch case with 
the change of the temperatues. As the position changes, the value changes and it has to be written to the servo. 
================================================================================*/
    switch(increment){
            case 20: PWM_1_WriteCompare(1500);
                     actualPWMPos = 0;
                     break;
            case 21: PWM_1_WriteCompare(1340);
                     actualPWMPos = 1;
                     break;
            case 22: PWM_1_WriteCompare(1180);
                     actualPWMPos = 2;
                     break;
            case 23: PWM_1_WriteCompare(1020);
                     actualPWMPos = 3;
                     break;
            case 24: PWM_1_WriteCompare(860);
                     actualPWMPos = 4;
                     break;
            case 25: PWM_1_WriteCompare(700);
                     actualPWMPos = 5;
                     break;
            default: break;
    }
}
void WriteEEPROM(){
/*================================================================================
This function writes all saved data to the EEPROM to save it for future purposes and overview.
The List below shows which data is saved where and in which position of the row.
            Marker   1.Date  2.Time  3.Temp  4.Humi  5.mois  6.Soiltemp_1  7.Soiltemp_2
            1Byte    4 Byte  2 Byte  1Byte   1Byte   3 Byte  2Byte         2Byte
Pos in Row  0        1-4     5-6     7       8       9       11-12         13-14
The Marker is not necessary for the code to run. It just shows the position in the EEPROM as a pointer: where
was the last place the last time data got saved. The current position gets the value 1.
For further explanation: The variable posEEPROM cointains information about the row, where the last data got saved.
The EEPROM is capable of saving more then 128 (rows) * 16 (Bytes) but there are only 100 rows used in this case.
Furthermore the first row (row '0') is used for saving the time and date of the system, therefore the data saving
starts in the second row (row'1') and goes to 100
================================================================================*/
    uint8 value;
    
    EEPROM_WriteByte(0, posEEPROM * 16);    // Taking last EEPROM Position and writing the marker to the next one
    posEEPROM++;                            
    EEPROM_WriteByte(1, posEEPROM * 16);    // Next position
    for(int i = 1; i < 7; i++){             // The time and date got saved in row '0' and are take over to the curren position  
            EEPROM_WriteByte(EEPROM_ReadByte(i), posEEPROM * 16 + i);
    }
    EEPROM_WriteByte(temperature, posEEPROM * 16 + 7);  // More data written to the EEPROM (pos 7)
    EEPROM_WriteByte(humidity, posEEPROM * 16 + 8);     // pos 8
    EEPROM_WriteByte(mois, posEEPROM * 16 + 9);         // pos 9
    EEPROM_WriteByte(0, posEEPROM * 16 + 10);           // Unused storage => writing 0 on this place
    value = soilTemp_1 / 10;        // A few values have to be converted (last number of value is a dezimal number)
    EEPROM_WriteByte(value, posEEPROM * 16 + 11);       // Pre dezimal of SoilTemp_1
    value = soilTemp_1 % 10;
    EEPROM_WriteByte(value, posEEPROM * 16 + 12);       // Dezimal of SoilTemp_1
    value = soilTemp_2 / 10;
    EEPROM_WriteByte(value, posEEPROM * 16 + 13);       // Pre dezimal of SoilTemp_2
    value = soilTemp_2 % 10;
    EEPROM_WriteByte(value, posEEPROM * 16 + 14);       // Dezimal of SoilTemp_2
    if(posEEPROM >= 100)        // After Reaching the row number 100 it gets reseted to 0
            posEEPROM = 0;      // When the function is called again -> posEEPROM++ ,because the first row is secured for the date and time
    EEPROM_WriteByte(posEEPROM,0);  // Save the actual 'pointer' (position) to row 1 (saved if system gets shut down)
}
void OneWireTemp(void){
/*================================================================================
When the Temperaturesensores are connected with the one wire system the following function can be called to get the
temperature values. To get the temperature, the master(microcontroller) has to send commands to the slave (sensor) in
a specific order. These functions get executed by calling function which send and receive Bytes (data-excahnge master slave). 
There is a different between a single sensor and multiple ones. This code handles multiple sensors.
================================================================================*/
            uint8 OWLSB;        // OneWire LeastSegnificantBit
            uint16 OWMSB;       // OneWire MostSignificantBit
    
            //OneWire (Part 1)
            OWTouchReset();     // Call reset funcion    
            OWWriteByte(0x55);  // Call function to write a fixed byte to the slave
            
            //Address 1: OWWriteByte(0x2895F19B0B00009B);   
            for(int h = 0; h < 8; h++)      
                    OWWriteByte(OneWireAddressValues[h]);   // Write 8 Byte to address a specific slave
            
            OWWriteByte(0x44);  // Call function to write a fixed byte to the slave
            OWTouchReset();     // Call reset funcion    
            OWWriteByte(0x55);  // Call function to write a fixed byte to the slave

            for(int k = 0; k < 8; k++)
                    OWWriteByte(OneWireAddressValues[k]);   // Write 8 Byte to address a specific slave second time

            OWWriteByte(0xBE);   // Call function to write a fixed byte to the slave
                        
            OWLSB = OWReadByte();       // Get the Least Significant Bit
            OWMSB = OWReadByte();       // Get the Most Significant Bit
            
            for(int i = 0; i < 8; i++)
            {
                    OWMSB <<= 1;    // Bitshift the Most Significant Bit to get the right value adn order
            }                       // The MSB represents Bit 9-16 in a 2 Byte long value
                                    // Order of reading single Bytes: 1. LSB, 2. MSB
                                    // Order we need for the right value: 1. MSB (Bit 9-16), 2. LSB (Bit 1-8)
                                    // So we create a 16 Bit value and bitshift the bits to the right position
            
            // Calculation to get 
            OWMSB += OWLSB;         // Bit 16-9 MSB + Bit LSB connected
            OWMSB *= 10;
            OWMSB /= 16;
            
            soilTemp_1 = OWMSB;     // The final value for the temperature
            
            
            //OneWire (Part 2) => nothing changes to Part one except the address of the Slave (Because second slave)
            OWTouchReset();            
            OWWriteByte(0x55);
            
            for(int y = 8; y < 16; y++)
                    OWWriteByte(OneWireAddressValues[y]);
            
            OWWriteByte(0x44);
            OWTouchReset();            
            OWWriteByte(0x55);
            
            //Address 2: OWWriteByte(0x280F809C0B0000C3);
            for(int f = 8; f < 16; f++)
                    OWWriteByte(OneWireAddressValues[f]);
            
            OWWriteByte(0xBE);
                       
            OWLSB = OWReadByte();       // Get the Least Significant Bit
            OWMSB = OWReadByte();       // Get the Most Significant Bit
            
            OWTouchReset();   
            
            for(int i = 0; i < 8; i++)
            {
                    OWMSB <<= 1;
            }

            OWMSB += OWLSB;
            OWMSB *= 10;
            OWMSB /= 16;
            
            soilTemp_2 = OWMSB;
}
void ControlUnit(void){
/*================================================================================
    This function turns the heater and water sprayer on and off depending on the temperature
    and air humidity.
================================================================================*/
        if(temperature <= 5)
        {
                extraHeating = TRUE;    // Turn on extra heating
                LED_1_Write(1);         // Signal for extra heating in progress
        }
        else if(temperature >= 10)
        {
                extraHeating = FALSE;   // Turn off extra heating
                LED_1_Write(0);         // Extra heating is off
        }
        
        if(humidity <= 30)              // 30% air humidity
                waterSprayer = TRUE;    // Turn on water sprayer
        else if(humidity >= 80)         // 80% air humidity
                waterSprayer = FALSE;   // Turn off water sprayer
}
void UserInput(void){
/*==============================================================================================
When a key on the keyboard got pressed, this function gets called and executes other functions depending on the 
input. Hence this function is a kind of director which handles the user input and saves them when needed.
The variable keyCounter controls the position in the char keySafe, so it is possible to input strings by jumping to
the next position after an input, else it wouldn't be possible to input multiple keys.
==============================================================================================*/
    switch(key){
        case 'd':
        case 'D':   keyCounter++;       // next position for a "String"
                    keySafe[0] = 'D';
                    UART_1_PutString("Pressed Key: ");
                    UART_1_PutChar(keySafe[0]);
                    UART_1_PutString("\n\n\rIf you want to know the date Press '?' and for writing a new date, press 'y', 'Y' or 'ENTER'\n\r");
                    UART_1_PutString("Else press 'q' or 'Q' to cancel\n\n\r");
                    break;
        case '?':   if(keyCounter == 1 && keySafe[0] == 'D')
                    {
                            ReadDateTime(1);    // Call function to print out the Date
                    }
                    else if(keyCounter == 1 && keySafe[0] == 'T')
                    {
                            ReadDateTime(2);    // Call function to print out the Time
                    }
                    else
                            UART_1_PutString("\n\n\n\r\"Greenhouse controller #1, developed by Peer Kroell\"\n\n\n\r");
                    keyCounter = 0;
                    break;
        case 't':
        case 'T':   keyCounter++;       // next position for a "String"
                    keySafe[0] = 'T';
                    UART_1_PutString("Pressed Key: ");
                    UART_1_PutChar(keySafe[0]);
                    UART_1_PutString("\n\n\rIf you want to know the time Press '?' and for writing a new time, press 'y', 'Y' or 'ENTER'\n\r");
                    UART_1_PutString("Else press 'q' or 'Q' to cancel\n\n\r");
                    break;
        case 'a':
        case 'A':   EEPROMPrintJSON();
                    break;
        case 0x0D:  // 'Enter'
        case 0x0A:  // 'Enter'
        case 'y':
        case 'Y':   // Confirmation for the Strin 'D?' and 'T?' 
                    if(keyCounter == 1 && keySafe[0] == 'D')
                    {
                        UART_1_PutString("Write a date in the following format: dd/mm/yyyy \n\r");
                        UART_1_PutString("Press 'q' or 'Q' to quit or 'del' to delete the last input\n\n\r");
                        UserWriteDate();
                    }
                    else if(keyCounter == 1 && keySafe[0] == 'T')
                    {
                        UART_1_PutString("Write the time in the following format: hh:mm \n\r");
                        UART_1_PutString("Press 'q' or 'Q' to quit or 'del' to delete the last input\n\n\r");
                        UserWriteTime();
                    }
                    else if(keyCounter == 1 && keySafe[0] == 'C'){
                            UART_1_PutString("\n\rIt might take a while\n\r");
                            ClearEEPROM();
                    }
                    keyCounter = 0; // Reset the Counter to position 0 after the code got executed
                    break;
        case 'c':
        case 'C':   keyCounter++;       // next position for a "String"
                    keySafe[0] = 'C';
                    UART_1_PutString("Pressed Key: ");
                    UART_1_PutChar(keySafe[0]);
                    UART_1_PutString("\n\n\rAre you sure you want to delete every data?\n\r");
                    UART_1_PutString("If yes, press 'y', 'Y' or 'ENTER' to continue\n\r");
                    UART_1_PutString("Else press 'q' or 'Q' to cancel\n\n\r");
                    break;
        case 'o':
        case 'O':   keySafe[0] = 'O';
                    UART_1_PutString("Pressed Key: ");
                    UART_1_PutChar(keySafe[0]);
                    keyCounter++;       // next position for a "String"
                    UART_1_PutString("\n\n\rYou can only save *ONE* sensor address at the time by having only *ONE* plugged in");
                    UART_1_PutString("\n\n\rIf you want to save the address, press '1' or '2' for the chosen storage slot\n\r");
                    UART_1_PutString("Else press 'q' or 'Q' to cancel to cancel\n\n\r");
                    break;
        case '1':   if(keyCounter == 1 && keySafe[0] == 'O'){   // Condition that 'O' had to be pressed first,
                                                                // before saving data to slot 1
                            OneWireAddress(1);                  
                            UART_1_PutString("Saved in slot 1\nr");
                            UART_1_PutString("If you want to save the other address, plug in the other sensor and press 'O' again\n\n\r");
                    }
                    keyCounter = 0;
                    break;
        case '2':   if(keyCounter == 1 && keySafe[0] == 'O'){   // Condition that 'O' had to be pressed first,
                                                                // before saving data to slot 2
                            OneWireAddress(2);
                            UART_1_PutString("Saved in slot 2\n\n\r");
                    }
                    keyCounter = 0;
                    break;
        case 'w':
        case 'W':   UART_1_PutString("\n\rPress 'q' or 'Q' to quit the live data output:\n\n\r");
                    keySafe[0] = 'W';
                    keyCounter++;
                    break;
        case 27 :   PrintTerminal();
                    break;
        case '0':   break;
        default:    if(keySafe[0] == 'W' || keySafe[0] == 'O' || keySafe[0] == 'D' || keySafe[0] == 'T')
                            UART_1_PutString("\n\n\rCanceled\n\n\r"); // When one of the keys above got pressed but the process
                                                                  // should be canceled, any key can be pressed to reset
                                                                  // the input
                    //key = '0';
                    keySafe[0] = 0;
                    keyCounter = 0;
                    break;
    }

    key = '0';      // Writing '0' to the key value. Else the switch case commands will be executed in a loop
    keySafe[1] = 0; // Resetting the keySafe char  
}
void UserWriteDate(void){
/*====================================================================================================
To be able to write the date the programm goes through a few steps of a writing process. The switch case goes 
through the steps of dd/mm/yyyy. At the same time the input gets printed to the console with the 
function "UserWriteDateTimeOut();" to get an overview about the current input. 
By pressing any button except a number, the process gets canceled. Additionaly, after the user finished
the input, the inputs will be checked for correctness by calling "UserWriteDateTimeProve(1)".
By pressing 'del' the last input gets deleted.
=====================================================================================================*/
    while(keyCounter){
        if(key >= '0' && key <= '9' && keyCounter >= 1){        
                keySafe[keyCounter] = key;  // Save the input to the actual position
                switch(keyCounter){
                    case 1:     UART_1_PutString("Current Input: "); 
                                UserWriteDateTimeOut();     // Print input
                                break;
                    case 2:     UART_1_PutString("Current Input: "); 
                                keyCounter++;               // write step 3 immediately because it is a separation (.../...)
                                keySafe[keyCounter] = '/';
                                UserWriteDateTimeOut();     // Print input
                                break;
                    case 4:     UART_1_PutString("Current Input: "); 
                                UserWriteDateTimeOut();     // Print input
                                break;
                    case 5:     UART_1_PutString("Current Input: "); 
                                keyCounter++;               // write step 6 immediately because it is a separation (.../...)
                                keySafe[keyCounter] = '/';
                                UserWriteDateTimeOut();     // Print input
                                break;
                    case 7:    
                    case 8:     
                    case 9:     UART_1_PutString("Current Input: "); 
                                UserWriteDateTimeOut();     // Print input
                                break;
                    case 10:    UART_1_PutString("Current Input: "); 
                                UserWriteDateTimeOut();             // Print input
                                if(!UserWriteDateTimeProve(1))      // Check if the date is valid
                                            UART_1_PutString("Date is not valid\n\r"); 
                                else{
                                            WriteDateTimeEEPROM(1);     // Writing the date to the EEPROM
                                            UART_1_PutString("Writing Date Succeeded: "); // Writing date Succeeded
                                            UserWriteDateTimeOut();     // Print input
                                }
                                keyCounter = 15;    // If the last input is done keyCounter = 15 to leave the loop
                                break;
                    default:    break;
                }
                keyCounter++;
                key = 0;
                if(keyCounter == 15)    // leave the loop
                        keyCounter = 0; 
        }
        else if(key == 'q' || key == 'Q' || keyCounter >= 11){  // press 'Q' to quit
                UART_1_PutString("\n\rQuit\n\r");
                keyCounter = 0;
        }
        else if(key == 127){        // delete the last input with 'del'
                keyCounter--;       // Take a step back to the last saving position
                if(keyCounter == 3 || keyCounter == 6)  // Position 3 and 6 are seperations of the day, month and year,
                                                        // so it gets skipped
                        keyCounter--;
                key = 0;
                UART_1_PutString("Current Input: ");
                keyCounter--;
                UserWriteDateTimeOut();     // Print out the last input
                keyCounter++;
        }
    }
}
void UserWriteTime(void){
/*====================================================================================================
To be able to write the time the programm goes through a few steps of a writing process. The switch case goes 
through the steps of hh/mm. At the same time the input gets printed to the console with the 
function "UserWriteDateTimeOut();" to get an overview about the current input. 
By pressing any button except a number, the process gets canceled. Additionaly, after the user finished
the input, the inputs will be checked for correctness by calling "UserWriteDateTimeProve(2)".
By pressing 'del' the last input gets deleted.
====================================================================================================*/
    while(keyCounter){
        if(key >= '0' && key <= '9' && keyCounter >= 1){
                
                keySafe[keyCounter] = key;  // Save the input to the actual position
                switch(keyCounter){
                    case 1:     UART_1_PutString("Current Input: "); 
                                UserWriteDateTimeOut();     // Print input
                                break;
                    case 2:     UART_1_PutString("Current Input: "); 
                                keyCounter++;
                                keySafe[keyCounter] = ':';
                                UserWriteDateTimeOut();     // Print input
                                break;
                    case 4:     UART_1_PutString("Current Input: "); 
                                UserWriteDateTimeOut();     // Print input
                                break;
                    case 5:     UART_1_PutString("Current Input: "); 
                                UserWriteDateTimeOut();     // Print input
                                 if(!UserWriteDateTimeProve(2))         // Check if the date is valid
                                            UART_1_PutString("Time is not valid\n\r"); 
                                else{
                                            WriteDateTimeEEPROM(2);     // Writing the date to the EEPROM
                                            UART_1_PutString("Writing Time Succeeded: "); // Writing date Succeeded
                                            UserWriteDateTimeOut();     // Print input
                                }
                                keyCounter = 15;    // If the last input is done keyCounter = 15 to leave the loop
                                break;
                    default:    break;
                }
                keyCounter++;
                key = 0;
                if(keyCounter == 15)    // leave the loop
                        keyCounter = 0;
        }
        else if(key == 'q' || key == 'Q' || keyCounter >= 11){  // leave the loop (press 'Q' to quit)
                UART_1_PutString("\n\rQuit\n\r");
                keyCounter = 0;
        }
        else if(key == 127){        // delete the last input with 'del'
                keyCounter--;       // Take a step back to the last saving position
                if(keyCounter == 3)     // Position 3 is a seperation the hours and minutes, so it will be skipped
                        keyCounter--;
                key = 0;
                UART_1_PutString("Current Input: ");
                keyCounter--;
                UserWriteDateTimeOut();     // Print out the last input
                keyCounter++;
        }
    }
}
void UserWriteDateTimeOut(void){
/*====================================================================================================
Print out the so far written date/time to the console 
====================================================================================================*/
        for(int i = 0; i < keyCounter; i++){    // Depending on how much is written already
            UART_1_PutChar(keySafe[i+1]);    // i+1, because the first Number is in [1]. [0] is a spaceholder
        }
        UART_1_PutString("\n\r");
}
int UserWriteDateTimeProve(int DateOrTime){
/*====================================================================================================
This function proves the time/date on correctness. If the value of passed parameter is 1, the date gets checked.
If it is 2 the time gets checked. Depending on the result the returnvalue is 1 = Correct, 0 = false.
====================================================================================================*/
    uint8 day, month;
    uint16 year;
    uint8 hours, minutes;
    
    if(DateOrTime == 1){
    // First the values have to be calculated to an uint8/uint16 value, because the numbers got saved in a char before
    // For example the input 12: char[1] = 1 and char[2] = 2 have to beconverted to 1 * 10 + 2 = 12
    // Because chars are used, the ASCII number has to be converted to rigth number with - 48
        day = (keySafe[1] - 48) * 10;
        day += (keySafe[2] - 48);
        
        month = (keySafe[4] - 48) * 10;
        month += (keySafe[5] - 48);
        
        year = (keySafe[7] - 48) * 1000;
        year += ((keySafe[8] - 48) * 100);
        year += ((keySafe[9] - 48) * 10);
        year += (keySafe[10] - 48);
        // Now the year, month and date gets checked for correctness
        if(year >= 2000 && year < 10000 && day > 0)
        {
                if(month == 2 && day <= 28)
                        return 1;
                else if((month == 4 || month == 6 || month == 9 || month == 11) && day <= 30)
                        return 1;
                else if(month <= 12 && day <= 31)
                        return 1;
        }
    }
    // The same proccess from the date is used for the time
    else if(DateOrTime == 2)
    {
        hours = (keySafe[1] - 48) *10;
        hours += (keySafe[2] - 48);
        
        minutes = (keySafe[4] - 48) *10;
        minutes += (keySafe[5] - 48);
        
        if(hours <= 23 && minutes <= 59)
                return 1;
    }
    return 0;
}
void WriteDateTimeEEPROM(int DateOrTime){
/*====================================================================================================
Here, if the input is correct, the written date and time are getting saved to the EEPROM. Depending on
passed parameter, the date (= 1) or the time (= 2) get written to the EEPROM. In the EEPROM there are
slots in row one reserved for every value, therefore the addresses in the command EEPROM_WriteByte(); are fixed.
            Marker   1.Day  2.Month 3.Year  4.Hour  5.Min
            1Byte    1Byte  1 Byte  2Byte   1Byte   1 Byte 
Pos in Row  0        1      2       3-4     5       6     
    (Marker = last row/position of stored data => gets called on every start of the program)
====================================================================================================*/
    uint8 writeEEPROM;
    
    if(DateOrTime == 1){
    // First the values have to be calculated to an uint8 value, because the numbers got saved in a char before
    // For example the input 12: char[1] = 1 and char[2] = 2 have to beconverted to 1 * 10 + 2 = 12
    // Because chars are used, the ASCII number has to be converted to rigth number with - 48
        writeEEPROM = (keySafe[1] - 48) * 10;
        writeEEPROM += (keySafe[2] - 48);
        EEPROM_WriteByte(writeEEPROM, 1);
        
        writeEEPROM = (keySafe[4] - 48);
        writeEEPROM += (keySafe[5] - 48);
        EEPROM_WriteByte(writeEEPROM, 2);
        
        writeEEPROM = (keySafe[7] - 48) * 100;
        writeEEPROM += (keySafe[8] - 48) * 10;
        writeEEPROM += (keySafe[9] - 48);
        EEPROM_WriteByte(writeEEPROM, 3);
        
        writeEEPROM = (keySafe[10] - 48);
        EEPROM_WriteByte(writeEEPROM, 4);
    }
    else if(DateOrTime == 2){
        writeEEPROM = (keySafe[1] - 48) * 10;
        writeEEPROM += (keySafe[2] - 48);
        EEPROM_WriteByte(writeEEPROM, 5);   
        
        writeEEPROM = (keySafe[4] - 48) * 10;
        writeEEPROM += (keySafe[5] - 48);
        EEPROM_WriteByte(writeEEPROM, 6); 
    }
}
void ReadDateTime(int DateOrTime){
/*====================================================================================================
This function prints the date and time of the device, which is saved to the EEPROM onto the console.
Depending on passed parameter, the date (= 1) or the time (= 2) get chosen.
====================================================================================================*/
    uint8 Data;
    char out[3];    // char for the outputs
    if(DateOrTime == 1){    // Date
            UART_1_PutString("Actual device date: ");
            for(int i = 1; i <= 2; i++){ // Every value has a specific saveslot in the EEPROM which gets used of in the for loop
                    Data = EEPROM_ReadByte(i); 
                    if(Data < 10)     // To get the right format with missing zeros => '0'5.'0'6 instead of 5.6
                            sprintf(out, "0%u/", Data);
                    else 
                            sprintf(out, "%u/", Data);
                    UART_1_PutString(out);
            }
            for(int u = 3; u <= 4; u++){ // Every value has a specific saveslot in the EEPROM which gets used of in the for loop
                    Data = EEPROM_ReadByte(u);
                    sprintf(out, "%u", Data);
                    UART_1_PutString(out);
            }
            UART_1_PutString("\n\n\r");
    }
    else if(DateOrTime == 2){   // Time
        UART_1_PutString("Actual device time: ");
        Data = EEPROM_ReadByte(5);  // Every value has a specific saveslot in the EEPROM
        if(Data < 10)       // To get the right format with missing zeros => '0'5:'0'6 instead of 5:6
                sprintf(out, "0%u:", Data);
        else
                sprintf(out, "%u:", Data);
        UART_1_PutString(out);
        Data = EEPROM_ReadByte(6);  // Every value has a specific saveslot in the EEPROM
        if(Data < 10)
                sprintf(out, "0%u\n\n\r", Data);
        else 
                sprintf(out, "%u\n\n\r", Data);
        UART_1_PutString(out);
    }
}
void TimeControl(void){
/*====================================================================================================
This function gets called after every minute, when the Interrup isr_TimeUpdate got actived.
So when executing this function, the clock and date will be read from the EEPROM and gets updated.
Then it will be written back to it again
====================================================================================================*/
    uint8 updateMin = EEPROM_ReadByte(6);   // Every value has a specific saveslot in the EEPROM
    uint8 updateHour = EEPROM_ReadByte(5);
    uint8 updateDay = EEPROM_ReadByte(1);
    uint8 updateMonth = EEPROM_ReadByte(2);
    uint8 updateYear = EEPROM_ReadByte(3) + EEPROM_ReadByte(4);
    
    updateMin++;    // this function only gets called every minute. Therefore them value minute gets increased
    if(updateMin == 60) // 1 hour = 60 miutes
    {
            updateMin = 0;  // reset to the first minute
            updateHour++;
            if(updateHour == 24)    // 1 day = 24 hours
            {       
                    // Depending on the day and in which month we are, the day has to be updated in different ways
                    updateHour = 0;
                    updateDay++;
                    if(updateDay == 32 && (updateMonth == 1 || updateMonth == 3 || updateMonth == 5 || updateMonth == 7 || updateMonth == 8 || updateMonth == 10 || updateMonth == 12)){
                            updateMonth++;
                            updateDay = 1;      // reset to the first day
                    }
                    else if(updateDay == 31 && (updateMonth == 4 || updateMonth == 6 || updateMonth == 9 || updateMonth == 11)){
                            updateMonth++;
                            updateDay = 1;      //reset to the first day
                    }
                    else if(updateDay == 29 && updateMonth == 2){
                            updateMonth++;
                            updateDay = 1;      // reset to the first day
                    }
                    if(updateMonth == 13){      // 1 year = 12 months
                            updateYear++;
                            updateMonth = 1;    // reset to the first month
                            // The year is split into two different Bytes. One contains 3 numbers, the other only one
                            EEPROM_WriteByte(updateYear / 10, 3);   // Write the update value to the EEPROM
                            EEPROM_WriteByte(updateYear % 10, 4);   // Write the update value to the EEPROM
                    }
                    EEPROM_WriteByte(updateMonth, 2);   // Write the update value to the EEPROM
                    EEPROM_WriteByte(updateDay, 1);     // Write the update value to the EEPROM
            }
            EEPROM_WriteByte(updateHour, 5);    // Write the update value to the EEPROM
    } 
    EEPROM_WriteByte(updateMin,6);  // Write the update value to the EEPROM
}
void EEPROMPrintJSON(void){
/*====================================================================================================
    Print out every saved data in JSON Format
====================================================================================================*/
    char out[100];
    char print[7];
    uint8 tmp[16];        // Store saved data from the EEPROM
    for(int i = 1; i < 101; i++){       // row 1 to 100
        
        for(int j = 1; j < 16; j++)    // One row has 16 Bytes
                tmp[j] = EEPROM_ReadByte(16*i+j); 
        sprintf(print, "Row %i:", i);
        UART_1_PutString(print);
        if(tmp[6] < 10)
                sprintf(out, "{\"Date\": %u.%u.%u%u, \"Time\": %u.0%u, \"Temp\": %uC, \"AirHumi\": %u%%, \"SoilMois\": %u, \"SoilTemp_1\": %u.%uC, \"SoilTemp_2\": %u.%uC}\n\r",tmp[1],tmp[2],tmp[3],tmp[4],tmp[5],tmp[6],tmp[7],tmp[8],tmp[9],tmp[11],tmp[12],tmp[13],tmp[14]);
        else
                sprintf(out, "{\"Date\": %u.%u.%u%u, \"Time\": %u.%u, \"Temp\": %uC, \"AirHumi\": %u%%, \"SoilMois\": %u, \"SoilTemp_1\": %u.%uC, \"SoilTemp_2\": %u.%uC}\n\r",tmp[1],tmp[2],tmp[3],tmp[4],tmp[5],tmp[6],tmp[7],tmp[8],tmp[9],tmp[11],tmp[12],tmp[13],tmp[14]);
        UART_1_PutString(out);
    }
    UART_1_PutString("\n\n\r");
}
void ClearEEPROM(void){
/*====================================================================================================
    When calling this function, every save slot (row 1 - 100) gets cleared by writing '0' everywhere
====================================================================================================*/
    for(int i = 0; i <= 1615; i++){
            EEPROM_WriteByte(0,i);      // Writing '0' to every saving slot
    }
    posEEPROM = 0;       // Reseting the 'pointer' of the last place, data got stored
    UART_1_PutString("\n\n\r!Deleting data succeded!\n\n\r");
}  
void PrintTerminal(void){
/*====================================================================================================
    Output of the user interface after pressing 'esc' to get information about the possible input parameters
====================================================================================================*/
    UART_1_PutString("User Terminal:\n\r");
    UART_1_PutString("'?'\t\t-Print developer information\n\r");
    UART_1_PutString("'T'\t\t-Set the time (hh:mm)\n\r");
    UART_1_PutString("'T?'\t\t-Current time\n\r");
    UART_1_PutString("'D'\t\t-Set the date (dd:mm:yyyy)\n\r");
    UART_1_PutString("'D?'\t\t-Current Date\n\r");
    UART_1_PutString("'A'\t\t-Print the saved data in JSON-Format\n\r");
    UART_1_PutString("'C'\t\t-Delete the saved data\n\r");
    UART_1_PutString("'W'\t\t-Print live data\n\r");
    UART_1_PutString("'O'\t\t-Safe OneWire address\n\r");
    UART_1_PutString("Press 'Esc' to see the Commands again\n\n\n\r");
}
void LiveData(void){
/*====================================================================================================
This function prints out the live data every 4 seconds for a simple overview of the measurents
====================================================================================================*/
    char out[200];
    OneWireTemp();
    UART_1_PutString("\n\rLive data:\n\n\r");
    sprintf(out, "Temp:\t%u C\n\rHumi:\t%u %%\n\rSoil_1:\t%u,%u C\n\rSoil_2:\t%u,%u C\n\rSoil_Mois: %u \n\n\r",temperature,humidity,soilTemp_1/10,soilTemp_1%10,soilTemp_2/10,soilTemp_2%10,ADC_DelSig_1_Read8());
    UART_1_PutString(out);
    if(extraHeating == 1)
            UART_1_PutString("Extra heating:\ton\n\r");
    else
            UART_1_PutString("Extra heating:\toff\n\r");
    if(waterSprayer == 1)
            UART_1_PutString("Watersprayer:\ton\n\r");
    else
            UART_1_PutString("Watersprayer:\toff\n\r");
    sprintf(out, "Position:\t %u %%\n\r\n", (actualPWMPos * 20));
    UART_1_PutString(out);
    UART_1_PutString("\nIf you want to quit press 'q' or 'Q'\n\n\r");
}
void OneWireAddress(int address){
/*====================================================================================================
    If only one dallas soil temperature sensor is connected, this function can be called to get the address of the
    connected sensor which is needed to measure temperatures and saves it to the EEPROM for later use
====================================================================================================*/
    uint8 ROMaddress;
    char out[3];
    // Specific order of Reset -> Write -> Read -> Reset
    OWTouchReset();     // Call function reset
    OWWriteByte(0x33);  // Write fixed value to be able to read next Byte
    for(int y = 0; y < 8; y++){         // 8 Byte long address
            ROMaddress = OWReadByte();         // Read Byte
            sprintf(out, "%x ", ROMaddress);   // Print out in hexa for better overview
            UART_1_PutString(out);      // output to console
            EEPROM_WriteByte(ROMaddress, 16*(100 + address) + y);    // Write address to the reserved space in EEPROM
    }                   // Dependeng on the wanted slot(int address = 1 or 2) it gets saved to row 101 or 102
    OWTouchReset();     // Call function reset
    keyCounter = 0;     // Resets the keyCounter = 0 to get ready for further inputs in the function UserInput(void)
}

/* INTERRUPTS */
CY_ISR(isr_TimerData){    
/*====================================================================================================
Interrupt seevice routine ever 15 minutes for saving the data to the EEPROM
====================================================================================================*/
    flagTimerData = TRUE;     // Set flag to be able to execute command in the main function every 15 min
                              // Gets reseted in the main function
    Timer_1_ReadStatusRegister();       // Reset the flag of the Timer ISR (so that the ISR can be executed again)
}
CY_ISR(isr_TimeUpdate){
/*====================================================================================================
Interrupt seevice routine ever 1 minute for updating the time (real time clock) and saving it to the EEPROM
====================================================================================================*/
    flagTime = TRUE;          // Set flag to be able to execute command in the main function every 1 min
                              // Gets reseted in the main function
    Timer_2_ReadStatusRegister();       // Reset the flag of the Timer ISR (so that the ISR can be executed again)
}
CY_ISR(isr_LiveData){
/*====================================================================================================
Interrupt seevice routine ever 1 minute for updating the time (real time clock) and saving it to the EEPROM
====================================================================================================*/
    flagLiveData = TRUE;      // Set flag to be able to execute command in the main function every 4 seconds
                              // Gets reseted in the main function
    Timer_3_ReadStatusRegister();       // Reset the flag of the Timer ISR (so that the ISR can be executed again)
}
CY_ISR(UART_ISR){               
/*====================================================================================================
ISR of the UART to be able to do a new input from the keyboard
====================================================================================================*/
	UART_1_ReadRxStatus();	    // Read the UART
	key = UART_1_GetChar();     // Get the Userinput
}